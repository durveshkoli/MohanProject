package com.mini.testcase;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.mini.helper.AssertHelper;
import com.mini.pageobject.FishAngelMenuPageObject;
import com.mini.pageobject.FishPageObject;
import com.mini.pageobject.HomePageObject;
import com.mini.pageobject.PaymentPageObject;
import com.mini.pageobject.SignInPageObject;


public class TestPage {

	static WebDriver driver = null;
	static HomePageObject homepage = null;
	static SignInPageObject signinpage = null;
	static FishPageObject fishpage = null;
	static FishAngelMenuPageObject anglefishpage = null;
	static PaymentPageObject paymentpage = null;
	
	public void login() throws InterruptedException{
		homepage.goToLogin();
		signinpage.login("durveshkoli", "12345678");
		
	}
	
	@BeforeClass
	public static void Launch(){
		
		System.setProperty("webdriver.chrome.driver","F:\\Selenium\\selenium-master\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("https://jpetstore.cfapps.io/catalog");
		homepage = new HomePageObject(driver);
		signinpage	= new SignInPageObject(driver);
		fishpage = new FishPageObject(driver);
		anglefishpage = new FishAngelMenuPageObject(driver);
		paymentpage = new PaymentPageObject(driver);
	}
	
	@Test
	public void testcase5() throws InterruptedException {
		
		homepage.goToLogin();
		signinpage.registerPage();
		String expectedmessage ="Your account has been created. Please try login !!";
		Assert.assertEquals("Your account has been created. Please try login !!", expectedmessage);
		
	}

	
	@Test
	public void testcase1() throws InterruptedException{
		
		login();
		driver.findElement(By.xpath("//*[@id=\"MainImageContent\"]/map/area[2]")).click();
		Assert.assertTrue(AssertHelper.isElementPresent(driver,By.xpath("//*[@id=\"Catalog\"]/table")));
		driver.findElement(By.linkText("Sign Out")).click();
		Thread.sleep(1000);
	}
	
	@Test
	public void testcase2() throws InterruptedException{
		
		login();
		homepage.fishMenu();
		fishpage.selectFish();
		anglefishpage.addToCart();
		WebElement count= driver.findElement(By.id("lines0.quantity"));
		Assert.assertEquals("1",count.getAttribute("value"));
		driver.findElement(By.linkText("Sign Out")).click();
		Thread.sleep(1000);

	}
	
	@Test
	public void testcase3() throws InterruptedException {
		
		login();
		homepage.searchPet();
		Assert.assertTrue(AssertHelper.isElementPresent(driver,By.xpath("//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[1]/a")));
		driver.findElement(By.linkText("Sign Out")).click();
		Thread.sleep(1000);

	}
	
	
	@Test
	public void testcase4() throws InterruptedException {
		
		login();
		homepage.fishMenu();
		fishpage.selectFish();
		anglefishpage.addToCart();
		anglefishpage.checkout();
		paymentpage.payment();
		String expectedmsg = "Thank you, your order has been submitted.";
		Assert.assertEquals("Thank you, your order has been submitted.", expectedmsg);
		driver.findElement(By.linkText("Sign Out")).click();
		Thread.sleep(1000);
		
	}
	
	
	
	
              
	
}

