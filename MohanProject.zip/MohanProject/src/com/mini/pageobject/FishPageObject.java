package com.mini.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FishPageObject {
	
	WebDriver driver;
	
	@FindBy(linkText = "FI-SW-01")
	private WebElement fishbutton;
	
	
	
	public FishPageObject (WebDriver driver){
		 this.driver =driver;
		 PageFactory.initElements(driver, this);		
	}
	
	public void selectFish(){
		fishbutton.click();
	}
}