package com.mini.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentPageObject {
	WebDriver driver;
	
	@FindBy(id = "cardType")
	private WebElement card;
	
	@FindBy(xpath = "//*[@id=\"cardType\"]/option[1]")
	private WebElement visa;
	
	@FindBy(id = "creditCard")
	private WebElement cardnumber;
	
	@FindBy(id = "expiryDate")
	private WebElement date;
	
	
	
	@FindBy(name = "continue")
	private WebElement continuebtn;
	
	@FindBy(id = "order")
	private WebElement submitbtn;
	
	
	public PaymentPageObject (WebDriver driver){
		 this.driver =driver;
		 PageFactory.initElements(driver, this);

	}
	
	public void payment() {
		
		card.click();
		visa.click();
		cardnumber.sendKeys("1234123412341234");
		date.sendKeys("09/2019");
		continuebtn.click();
		submitbtn.click();
		
		/*
		fname.sendKeys("Durvesh");
		lname.sendKeys("Koli");
		addressline1.sendKeys("Dk Villa");
		addressline2.sendKeys("Sanpada");
		city.sendKeys("Navi Mumbai");
		state.sendKeys("Maharashtra");
		pincode.sendKeys("400705");*/
	}
}
