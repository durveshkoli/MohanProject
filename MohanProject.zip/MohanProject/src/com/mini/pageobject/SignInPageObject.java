package com.mini.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignInPageObject {
	
	WebDriver driver;
	
	@FindBy(name = "username")
	private WebElement uname;
	
	@FindBy(name = "password")
	private WebElement pwd;
	
	@FindBy(id = "login")
	private WebElement loginbutton;
	
	
	//REGISTER PAGE
	
	@FindBy(linkText  = "Register Now!")
	private WebElement register;
	
	@FindBy(name = "username")
	private WebElement userid;
	
	@FindBy(id = "password")
	private WebElement regpass;
	
	@FindBy(id = "repeatedPassword")
	private WebElement repeatpass;
	
	@FindBy(id = "firstName")
	private WebElement fname;
	
	@FindBy(id = "lastName")
	private WebElement lname;
	
	@FindBy(id = "email")
	private WebElement Email;
	
	@FindBy(id = "phone")
	private WebElement phonenum;
	
	@FindBy(id = "address1")
	private WebElement addressline1;
	
	@FindBy(id = "address2")
	private WebElement addressline2;
	
	@FindBy(id = "city")
	private WebElement City;
	
	@FindBy(id = "state")
	private WebElement State;
	
	@FindBy(id = "zip")
	private WebElement pincode;
	
	@FindBy(id = "country")
	private WebElement Country;
	
	@FindBy(id = "languagePreference")
	private WebElement selectlanguage;
	
	@FindBy(xpath = "//*[@id=\"languagePreference\"]/option[1]")
	private WebElement Englishlanguage;
	
	@FindBy(id = "favouriteCategoryId")
	private WebElement selectcategory;
	
	@FindBy(xpath = "//*[@id=\"favouriteCategoryId\"]/option[3]")
	private WebElement reptilecategory;
	
	@FindBy(id = "save")
	private WebElement saveaccountbtn;
	
	
	public SignInPageObject (WebDriver driver){
		 this.driver =driver;
		 PageFactory.initElements(driver, this);
	 } 
	 public void login(String name, String password){
		 uname.sendKeys(name);
		 pwd.sendKeys(password);
		 loginbutton.click();
		 
	 }
	 
	 public void registerPage() {
		 
		 register.click();
		 userid.sendKeys("mohanramola");
		 regpass.sendKeys("12345678");
		 repeatpass.sendKeys("12345678");
		 fname.sendKeys("Mohan");
		 lname.sendKeys("Ramola");
		 Email.sendKeys("mohanramola@gmail.com");
		 phonenum.sendKeys("7977105412");
		 addressline1.sendKeys("MR Villa");
		 addressline2.sendKeys("Chembur");
		 City.sendKeys("Mumbai");
		 State.sendKeys("Maharashtra");
		 pincode.sendKeys("400703");
		 Country.sendKeys("India");
		 selectlanguage.click();
		 Englishlanguage.click();
		 selectcategory.click();
		 reptilecategory.click();
		 saveaccountbtn.click();
		 
	 }

}

