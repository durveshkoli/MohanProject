package com.mini.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FishAngelMenuPageObject {
	
	WebDriver driver;
	
	@FindBy(linkText = "Add to Cart")
	private WebElement cartbutton;
	
	@FindBy(linkText = "Proceed to Checkout")
	private  WebElement checkoutbtn;
	
	
	public FishAngelMenuPageObject (WebDriver driver){
		 this.driver =driver;
		 PageFactory.initElements(driver, this);

	}
	
	public void addToCart(){
		cartbutton.click();
	}
	
	public void checkout() {
		checkoutbtn.click();
	}
	

}
