package com.mini.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePageObject {
	
	 WebDriver driver;
	 
	 @FindBy(xpath = "//*[@id=\"MenuContent\"]/a[2]")
	 private WebElement signin;
	 
	 @FindBy(xpath = "//*[@id=\"MainImageContent\"]/map/area[2]")
	 private WebElement fishlink;
	 
	 @FindBy(name = "keywords")
	 private WebElement search;
	 
	 @FindBy(id = "searchProducts")
	 private WebElement searchbtn;
	 
	 public HomePageObject (WebDriver driver){
		 this.driver =driver;
		 PageFactory.initElements(driver, this);
	 } 
	 
	 public void  goToLogin() throws InterruptedException{
		 signin.click();
	 }
	 
	 public void fishMenu(){
		 fishlink.click();
		 
	 }
	 
	 public void searchPet() {
		 search.sendKeys("angelfish");
		 searchbtn.click();
	 }
	
	 
	 
	 

}

